#!/bin/bash

# Check if any arguments are provided
if [ "$#" -eq 0 ]; then
    echo "No arguments provided."
    exit 1
fi

# Iterate over each positional parameter
for i in "$@"; do
    # Get the position of the current argument
    pos=$((++count))
    echo "\$${pos} = $i"
done



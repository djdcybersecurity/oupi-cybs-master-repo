#!/bin/bash

# Function to display the menu
display_menu() {
    echo "----------------------------"
    echo "     Interactive Menu       "
    echo "----------------------------"
    echo "1. Display a custom message"
    echo "2. Print the current date and time"
    echo "3. Exit"
    echo "Please choose an option (1-3): "
}

# Main loop
while true; do
    display_menu
    read -r choice  # Prompting user for input

    case $choice in
        1)
            echo "You have selected to display a custom message."
            echo "Hello, this is your custom message!"
            ;;
        2)
            echo "You have selected to print the current date and time."
            date  # Display the current date and time
            ;;
        3)
            echo "Exiting the script. Goodbye!"
            exit 0  # Exit the script
            ;;
        *)
            echo "Invalid option, please try again."
            ;;
    esac
    echo ""  # Print a new line for better readability
done



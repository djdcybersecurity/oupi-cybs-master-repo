# SFTP Assignment Instructions

1. Connect to the SFTP server with the provided credentials.
2. Navigate to the `/shared` directory and locate the file `target_file_001.txt`.
3. Download `target_file_001.txt` to your local machine.
4. Add the file to this repository.
5. Commit and push your changes.

The GitHub Workflow will check if `target_file_001.txt` is present in your repository.


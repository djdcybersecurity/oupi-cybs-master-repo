#!/bin/bash


#Function to create directories and clue files
create_adventure() {
	local level=$1
	local base_dir="direction_$level"
	
	# Create the directory, based off user prompt
	mkdir -p "$base_dir"
	
	#unique clue generated for each direction
	if [ $level -eq $num_levels ]; then
		echo "Congratulations!!!!!!! You found the pot of gold my brother!" > "$base_dir/VICTORY.txt"
	 else
        case $level in
            1) echo "Now that you've made it, we can let the viking's on the ship know that we're ready to sail. If we are lucky, we may find the treasure on our next voyage to the new lands. Let's move to direction_$((level + 1))." > "$base_dir/clue.txt" ;;
            2) echo "In the horizon there is promising lands in the distance. The rising sun illuminates a narrow path this way. What will we find going to direction_$((level + 1))." > "$current_dir/clue.txt" ;;
            3) echo "A distant sound of enemies beating drums. It might worth investigating direction_$((level + 1))." > "$base_dir/clue.txt" ;;
            4) echo "You must listen to your heart to lead you to the correct path. On any journey, there's always a clue that guides us somewhere maybe we'll be lucky on this last one, onto direction_$((level + 1))." > "$base_dir/clue.txt" ;;
        esac
    fi
    
    # If we haven't reached the last level, recursively create the next level
    if [ $level -lt $num_levels ]; then
        create_adventure $((level + 1))
    fi
}

# Prompt user for number of levels with validation loop
while true; do
    read -p "Enter the number of directory levels to create (no less than 2, no more than 4): " num_levels

    # Validate input
    if [[ "$num_levels" =~ ^[0-9]+$ ]] && [ "$num_levels" -ge 2 ] && [ "$num_levels" -le 4 ]; then
        break  # loop exit's if input is valid
    else
        echo "Invalid input, trooper. Please enter a valid number between 2 and 4."
    fi
done

# Start creating the game from level 1
create_adventure 1

echo "Adventure game directories created successfully!"

# Start an interactive shell

exec /bin/bash

#!/bin/bash

# Script Name: setup_directory_structure.sh
# Description: Creates a complex directory structure for the find command assignment.
# Usage: Run this script in the root of your repository.

# Base directory for the assignment
BASE_DIR="find_practice"

# Remove existing directory if it exists
rm -rf "$BASE_DIR"

# Create the base directory
mkdir -p "$BASE_DIR"

# Navigate to the base directory
cd "$BASE_DIR" || exit 1

# Function to create files with random content
create_random_file() {
    local filename=$1
    local size=$2
    head -c "$size" /dev/urandom > "$filename"
}

# Function to create files with specific content
create_text_file() {
    local filename=$1
    local content=$2
    echo -e "$content" > "$filename"
}

# Create subdirectories with varying depth
mkdir -p dirA/dirB/dirC
mkdir -p dirA/dirD
mkdir -p dirE/dirF
mkdir -p dirE/dirG/dirH/dirI
mkdir -p dirJ
mkdir -p .hidden_dir/dirK

# Create files with different extensions
touch file1.txt
touch file2.log
touch file3.conf
touch dirA/file4.txt
touch dirA/dirB/file5.log
touch dirA/dirD/file6.md
touch dirE/dirF/file7.sh
touch dirE/dirG/dirH/file8.py
touch dirJ/file9.cpp
touch .hidden_file

# Create files with special characters in names
touch "file with spaces.txt"
touch "file-with-hyphens.txt"
touch "file_with_underscores.txt"
touch "fileüníçødé.txt"
touch "file#special!.txt"

# Create files of varying sizes (reduced sizes to keep repository small)
create_random_file "largefile1.bin" 1M
create_random_file "largefile2.bin" 2M
create_random_file "dirA/dirB/largefile3.bin" 512K
create_random_file "dirE/dirG/dirH/largefile4.bin" 1M

# Create empty files
touch emptyfile1
touch dirA/emptyfile2
touch dirE/dirF/emptyfile3

# Create hidden files
touch .hidden_file1
touch dirA/.hidden_file2
touch dirE/dirG/.hidden_file3

# Create symbolic links (relative links)
ln -s ../file1.txt dirA/dirB/dirC/link_to_file1.txt
ln -s ../../../../largefile2.bin dirE/dirG/dirH/link_to_largefile2.bin

# Create files with specific modification times
create_text_file "oldfile1.txt" "This is an old file."
create_text_file "recentfile1.txt" "This is a recent file."
# Set modification time to 30 days ago
touch -m -d "30 days ago" oldfile1.txt
# Recent file has current timestamp

# Create files with specific permissions
create_text_file "executable_script.sh" "#!/bin/bash\necho 'Hello World'"
chmod +x executable_script.sh
create_text_file "readonly_file.txt" "This file is read-only."
chmod 444 readonly_file.txt

# Create files containing specific text patterns
create_text_file "todo_list.txt" "TODO: Finish the assignment\nDONE: Review the code\nTODO: Submit the work"
create_text_file "notes.md" "# Notes\n- Remember to check logs.\n- Error handling needs improvement."
create_text_file "error_log.log" "ERROR: Unable to connect to database.\nINFO: Retry in 5 seconds.\nERROR: Connection failed."

# Generate a large number of files for extensive searching
for i in {1..100}; do
    touch "file_$i.tmp"
    if (( i % 2 == 0 )); then
        echo "Sample content for file $i" > "file_$i.tmp"
    fi
done

# Create nested directories with similar file names
mkdir -p dirL/dirM/dirN
touch dirL/file_duplicate.txt
touch dirL/dirM/file_duplicate.txt
touch dirL/dirM/dirN/file_duplicate.txt

# Create files with same name but different extensions
touch dirJ/project.c
touch dirJ/project.h
touch dirJ/project.o

# Create files with varying access and modification times
create_text_file "accessed_today.txt" "This file was accessed today."
create_text_file "modified_5_days_ago.txt" "This file was modified 5 days ago."
touch -a "accessed_today.txt"
touch -m -d "5 days ago" "modified_5_days_ago.txt"

# Create some broken symbolic links
ln -s non_existent_file.txt broken_link1
ln -s ../non_existent_file.txt dirA/dirD/broken_link2

# Output completion message
echo "Directory structure created successfully in $(pwd)"

# Instructions for the instructor
echo "You can now commit the directory structure to your repository."


# find-practice
Directory and file structure to practice find, locate, fzf, and ripgrep commands.

# **Assignment: Text Processing and Regular Expressions**

In this assignment, you will use several Linux text processing tools (`cat`, `sort`, `uniq`, `grep`, `sed`) to manipulate files and extract useful information. Each task must be completed in your local environment, and the results should be saved to specific output files.

## **Instructions:**
1. Complete the tasks below in your Linux environment.
2. Save the outputs to the corresponding filenames as instructed.
3. Push the results to your GitHub repository.
4. A GitHub Workflow will automatically run to verify your results.

---

## **Tasks**

### **Task 1: Concatenate Files with `cat`**
Concatenate `file1.txt` and `file2.txt` using a command that numbers the lines. Save the output as `concatenated.txt`.

**Helpful Tip:**
- The `cat` command can be used to concatenate multiple files into one. Use an option to add line numbers to the output.
- **Tip on redirecting output:** You can use `>` to direct the output of your command to a file. For example, `command > output.txt` will save the result of the command to `output.txt`.

### **Task 2: Sort a File with `sort`**
Sort the contents of `unsorted.txt` alphabetically. Save the result as `sorted.txt`.

**Helpful Tip:**
- The `sort` command will arrange lines alphabetically. Ensure that the output is redirected to the appropriate file using `>`.

### **Task 3: Remove Duplicates with `uniq`**
Sort `duplicates.txt`, then remove the duplicate lines. Save the result as `unique.txt`.

**Helpful Tip:**
- Use `sort` before applying `uniq` to remove duplicate lines from the sorted output.
- Don’t forget to redirect the output to a file using `>`.

### **Task 4: Find IP Addresses using Regular Expressions and `grep`**
Use `grep` with a regular expression to find all lines in `log.txt` that contain an IP address. Save the results as `ip_addresses.txt`.

**Helpful Tip:**
- IP addresses follow a specific pattern involving numbers and dots. Use a regular expression with `grep` to search for this pattern.
- **Example:** You can use a pipe (`|`) to feed the results of one command into another. For example, you could use `grep` to find lines containing an IP address and then pipe that into another command to refine the results.
- Redirect the output of the `grep` command to `ip_addresses.txt` using `>`.

### **Task 5: Search for Errors and Warnings with `grep`**
Use `grep` to search for lines in `log.txt` that contain either "ERROR" or "WARNING" (case-insensitive). Save the results as `errors_and_warnings.txt`.

**Helpful Tip:**
- The `grep` command can search for multiple patterns at once. Use the option that allows case-insensitive matching and regular expressions.
- Remember to save the output to a file using `>`.

### **Task 6: Replace Text with `sed`**
Use `sed` to replace the word "old" with "new" in `replace.txt`. Save the output as `replaced.txt`.

**Helpful Tip:**
- `sed` can perform a search-and-replace function on text. Look for an option that will replace every occurrence of a word in the file.
- After performing the replacement, use `>` to save the updated content to `replaced.txt`.

---

## **Submission Instructions:**

1. Complete the tasks and generate the output files as instructed.
2. Push the output files (`concatenated.txt`, `sorted.txt`, `unique.txt`, `ip_addresses.txt`, `errors_and_warnings.txt`, `replaced.txt`) to your GitHub repository.
3. A GitHub Workflow will automatically verify your results.

#!/bin/bash

# Search for all occurrences of the lowercase 'conversation' in all .txt files within the fine_literature directory and its subdirectories
# Use find to locate all .txt files, and grep to find matches

# Store the total occurrences of the word 'conversation' including in other words
total_count=$(find fine_literature -name "*.txt" -exec grep -o "conversation" {} + | wc -l)

# Display the total count of lines on the terminal
echo "The keyword 'conversation' appears in $total_count lines."

# Write the total count to keyword_line_count.txt, only the number, without any additional text
echo $total_count > keyword_line_count.txt


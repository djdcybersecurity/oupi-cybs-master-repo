# vim-essay-practice
Practice your vim skills using example essays

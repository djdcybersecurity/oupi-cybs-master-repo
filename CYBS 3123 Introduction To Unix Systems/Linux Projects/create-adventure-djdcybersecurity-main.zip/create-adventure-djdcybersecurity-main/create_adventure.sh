#!/bin/bash

# Global variable to hold number of levels
levels=0

# Function to validate user input
function get_directory_levels() {
    while true; do
        read -p "Enter the number of directory levels (minimum 2): " levels
        if [[ "$levels" =~ ^[0-9]+$ ]] && [ "$levels" -ge 2 ]; then
            return 0  # Successfully validated input
        else
            echo "Please enter a valid number greater than or equal to 2."
        fi
    done
}

# Function to create directories and clue files with quests
function create_game_structure() {
    local current_path="level_1"
    mkdir -p "$current_path"

    for ((i=1; i<=$levels; i++)); do
        echo "Welcome to level $i! Solve the mystery to proceed." > "$current_path/clue.txt"
        echo "Your quest: Find the hidden treasure!" >> "$current_path/clue.txt"
        
        # Additional clues for levels 5 and 6
        if [ $i -eq 5 ]; then
            echo "Your quest: Discover the ancient artifact!" >> "$current_path/clue.txt"
            echo "Hint: Beware of the guardian!" >> "$current_path/clue.txt"
        elif [ $i -eq 6 ]; then
            echo "Congratulations! You have reached the final destination!" >> "$current_path/clue.txt"
            echo "Final Quest: Uncover the secret of the treasure!" >> "$current_path/clue.txt"
        fi
        
        if [ $i -lt $levels ]; then
            next_level="level_$((i + 1))"
            mkdir -p "$next_level"
            echo "To reach the next level, go to: $next_level" >> "$current_path/clue.txt"
            echo "Hint: Look for the map!" >> "$current_path/clue.txt"
            current_path="$next_level"
        fi
    done
}

# Function to display level information
function show_level_info() {
    local level_path="$1"
    if [ -f "$level_path/clue.txt" ]; then
        cat "$level_path/clue.txt"
    else
        echo "You are in an unknown location."
    fi
}

# Function to simulate user commands
function user_commands() {
    local current_level=1
    local max_levels=$1
    
    while true; do
        echo -e "\nYou are currently at Level $current_level."
        show_level_info "level_$current_level"
        
        echo -n "Enter a command (go [level number], check clues, exit): "
        read command
        
        case $command in
            go\ *)
                target_level=${command:3}
                if [[ $target_level =~ ^[1-9][0-9]*$ ]] && [ "$target_level" -le "$max_levels" ] && [ "$target_level" -gt 0 ]; then
                    current_level=$target_level
                else
                    echo "Invalid level. Please enter a number between 1 and $max_levels."
                fi
                ;;
            check\ clues)
                show_level_info "level_$current_level"
                ;;
            exit)
                echo "Thanks for playing! Your adventure ends here."
                break
                ;;
            *)
                echo "Unknown command. Please try again."
                ;;
        esac
    done
}

# Main script execution
get_directory_levels
create_game_structure
user_commands $levels

echo "Adventure game structure created with $levels levels."


#!/bin/bash

# Default playback duration
DEFAULT_DURATION=2

# Playlist
playlist=(
    "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"
    "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4"
    "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4"
    "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4"
    "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4"
    "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4"
    "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4"
    "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4"
)

# Function to validate playback duration
validate_duration() {
    if ! [[ "$1" =~ ^[0-9]+$ ]] || [ "$1" -le 0 ]; then
        echo "Error: Playback duration must be a positive integer."
        exit 1
    fi
}

# Check for GStreamer
command -v gst-launch-1.0 >/dev/null 2>&1 || {
    echo "Error: GStreamer is not installed. Please install it and try again."
    exit 1
}

# Handle command-line argument
if [ "$#" -eq 1 ]; then
    validate_duration "$1"
    playback_duration="$1"
else
    playback_duration=$DEFAULT_DURATION
fi

echo "Playback duration set to $playback_duration seconds per video."

# Trap for SIGINT
cleanup() {
    echo "Gracefully stopping playback..."
    [ -n "$video_pid" ] && kill "$video_pid" 2>/dev/null
    wait "$video_pid" 2>/dev/null
    exit 0
}
trap cleanup SIGINT

# Function to play a video
play_video() {
    local video_url="$1"
    echo "Playing video: $(basename "$video_url") for $playback_duration seconds."
    gst-launch-1.0 playbin uri="$video_url" >/dev/null 2>&1 &
    video_pid=$!
    sleep "$playback_duration"
    kill "$video_pid" 2>/dev/null
    wait "$video_pid" 2>/dev/null
}

# Main loop
while true; do
    # Shuffle the playlist
    shuffled_playlist=($(shuf -e "${playlist[@]}"))
    for video in "${shuffled_playlist[@]}"; do
        play_video "$video"
    done
done


#!/bin/bash

# Define the input file

FILE="input.txt"

# TODO: Add a command to check if the file exists
# Hint: You can use an if statement to check for the existence of the file
# If the file doesn't exist, print a message and exit the script.
# Initialize a line counter

line_count=0

# TODO: Use a while loop to read the file line by line
# Hint: Use a special command to read from the file and store the lines in a variable
# Increment the line counter for each line, and display the line using echo
# After the loop, display the total number of lines using echo



# Check if the input file exists
if [[ ! -f input.txt ]]; then
    echo "Error: input.txt not found!"
    exit 1
fi

# Initialize line counter
line_count=0

# Read the file line by line
while IFS= read -r line; do
    # Display each line
    echo "Line: $line"
    # Increment line counter
    ((line_count++))
done < input.txt

# Print the total number of lines
echo "Total lines: $line_count"


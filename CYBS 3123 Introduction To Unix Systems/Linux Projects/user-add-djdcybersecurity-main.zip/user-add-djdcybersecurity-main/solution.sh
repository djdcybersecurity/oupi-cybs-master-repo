#!/bin/bash

# This script sets up users, groups, and permissions as per the assignment instructions.
# Refer to your reading assignment for guidance on the commands and their usage.

# Add your commands below. Replace placeholders with actual values where necessary.

# 1. Create two new users with home directories.
# Hint: Use the command to add a user and create a home directory.

# Create user1
# Command to create user1
sudo useradd -m -s /bin/bash user1

# Create user2
# Command to create user2
sudo useradd -m -s /bin/bash user2

# 2. Create a new group.
# Hint: Use the command to add a group.

# Create group1
# Command to create group1
sudo groupadd group1


# 3. Add the users to the new group.
# Hint: Use the command to modify a user and add them to a group.

# Add user1 to group1
# Command to add user1 to group1
sudo usermod -aG group1 user1

# Add user2 to group1
# Command to add user2 to group1
sudo usermod -aG group1 user2


# 4. Create a shared directory.
# Hint: Use the command to create a directory.

# Create /home/shared
sudo mkdir /home/shared


# 5. Set the group ownership of the directory.
# Hint: Use the command to change group ownership of a file or directory.

# Change group ownership of /home/shared to group1
# Command to change group ownership
sudo chgrp group1 /home/shared
# 6. Set the permissions of the directory.
# Hint: Use the command to change permissions of a file or directory.

# Set permissions so group members have full access, others have none
# Command to set permissions
sudo chmod 770 /home/shared

# End of script
echo "Users and group created, and shared directory set up successfully."

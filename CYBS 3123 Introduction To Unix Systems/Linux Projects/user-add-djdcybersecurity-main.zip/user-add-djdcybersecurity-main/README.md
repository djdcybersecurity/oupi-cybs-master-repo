# Linux User and Permissions Assignment

## Objective

Demonstrate your understanding of Linux user creation, group management, and file permissions using the command line.

## Instructions

1. **Create Users and Groups via the Terminal**

   - **Create two new users:** `user1` and `user2`, each with a home directory.
   - **Create a new group:** `group1`.
   - **Add `user1` and `user2` to `group1`.

2. **Set Up Directories and Permissions via the Terminal**

   - **Create a directory:** `/home/shared`.
   - **Set the group owner** of `/home/shared` to `group1`.
   - **Set permissions** so that:
     - Members of `group1` have read, write, and execute permissions on `/home/shared`.
     - Others have no permissions on `/home/shared`.

3. **Documentation**

   - Write all commands in a script file named `solution.sh`.
   - Ensure your script is executable by running `chmod +x solution.sh`.
   - Verify that your script can be run without errors.

## Submission

- **Commit your `solution.sh` file** to this repository.
- **Push your changes** to GitHub.

## Grading

Your submission will be automatically graded using GitHub Actions. Ensure your `solution.sh` script:

- Executes without errors.
- Performs all tasks as specified in the instructions.

---



#!/bin/bash
touch ~/diary/$(date +%F).txt

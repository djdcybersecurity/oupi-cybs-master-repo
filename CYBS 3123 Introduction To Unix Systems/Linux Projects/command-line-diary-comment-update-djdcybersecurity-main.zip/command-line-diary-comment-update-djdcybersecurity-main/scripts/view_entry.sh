#!/bin/bash
#Hello my name is Daren and I am a student at the University of Oklahoma
cat ~/diary/$(date +%F).txt

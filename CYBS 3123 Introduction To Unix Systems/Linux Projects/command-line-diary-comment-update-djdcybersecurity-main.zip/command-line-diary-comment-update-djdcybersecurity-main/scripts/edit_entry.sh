#!/bin/bash
vim ~/diary/$(date +%F).txt

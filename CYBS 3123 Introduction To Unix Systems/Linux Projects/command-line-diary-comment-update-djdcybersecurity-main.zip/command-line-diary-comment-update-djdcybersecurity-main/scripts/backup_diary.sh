#!/bin/bash
tar -czvf ~/diary_backup.tar.gz ~/diary

#!/bin/bash
ls -l ~/diary

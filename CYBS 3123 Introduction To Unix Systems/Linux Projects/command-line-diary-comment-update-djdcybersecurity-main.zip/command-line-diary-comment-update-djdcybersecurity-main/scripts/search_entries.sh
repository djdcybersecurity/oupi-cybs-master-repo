#!/bin/bash
grep -rnw ~/diary -e "$1"

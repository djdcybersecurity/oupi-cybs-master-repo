#!/bin/bash
mkdir -p ~/diary/archive
mv ~/diary/$1.txt ~/diary/archive/

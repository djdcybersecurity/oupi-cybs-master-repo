# Command Line Diary Utility -- Comment update

## Objective
This project is a simple Command Line Diary application. All you are to do in this assignment is add one comment to one file and push the changes to your repository.
The file you need to change is called view_entry.sh.  You can find this file in the scripts directory. All you need to do is to load the file into your editor, vim.
Then, add a second line to the file, similar to the following:

# Here is my comment. My name is Emily Sooner.

Put anything you want in the above comment, as long as it starts with a #.
Save your file. Then, you need to commit you changes, then push, as follows.
On the command line, type:
    git add .     
Then you will type
    git commit -m "Added a second comment, as required"   
Note that you can put anything in the commit message
Then you need to push your changes to GitHub
    git push

Next, you go back to your browser and see if the GitHub Actions test is good.
If so, you are done.


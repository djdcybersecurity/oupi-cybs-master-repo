#!/bin/bash

# Check if at least two arguments are provided
if [ "$#" -lt 2 ]; then
    echo "You must provide at least two arguments."
    exit 1
fi

# Display arguments before using shift
echo "Before shift:"
for i in $(seq 1 $#); do
    echo "\$${i} = ${!i}"
done

# Use shift to remove the first argument
shift

# Display remaining arguments after using shift
echo ""
echo "After shift:"
for i in $(seq 1 $#); do
    echo "\$${i} = ${!i}"
done


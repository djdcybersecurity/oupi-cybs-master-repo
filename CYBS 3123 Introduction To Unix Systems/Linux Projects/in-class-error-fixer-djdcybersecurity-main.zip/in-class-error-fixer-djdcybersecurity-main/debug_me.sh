#!/bin/bash

# Check if a filename is provided as an argument
if [ "$#" -ne 1 ]; then
    echo "Usage: $0 filename"
    exit 1
fi

filename="$1"

# Check if the file exists
if [[ ! -f "$filename" ]]; then
    echo "Error: File '$filename' does not exist."
    exit 1
fi

# Initialize line counter
line_count=0

# Display the contents of the file line by line
echo "File '$filename' contains:"
while IFS= read -r line; do
    echo "Line $((line_count + 1)): $line"
    ((line_count++))
done < "$filename"

# Print the total number of lines
echo "Total lines: $line_count"

